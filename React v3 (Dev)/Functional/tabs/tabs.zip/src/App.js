import logo from './logo.svg';
import './App.css';
import Taps from './components/Taps';


function App() {
  return (
    <div className="App">
        <Taps/>
    </div>
  );
}

export default App;
