const ShowComponent = () => {
    return (
        <div>
display
        </div>
    )
}

export default ShowComponent
