import logo from './logo.svg';
import './App.css';

function App() {
    return (

        <
        div className = "class" >
        <
        h1 > Hello Dojo! < /h1> <
        h2 > Things i need to do : < /h2> <
            ul >
            <
            li > Learn React < /li> <
            li > climb mt Everest < /li> <
            li > run a marthon < /li> <
            li > feed the do </li> <
                /ul> <
                /div>

    );
}

export default App;